const Error404Screen ={
    render:() =>{
        return `<div>Page not Found!</div.>`
    },
};
export default Error404Screen;